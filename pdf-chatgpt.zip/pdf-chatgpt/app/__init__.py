"""PDF-ChatGPT application package."""

__version__ = "1.0.0"
